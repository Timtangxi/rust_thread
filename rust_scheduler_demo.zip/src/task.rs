use crate::context::Context;

#[derive(Debug, Clone)]
pub enum TaskState {
    Ready,
    Running,
    Sleeping,
    Zombie,
}

#[derive(Clone)]
pub struct Task {
    pub id: usize,
    pub name: &'static str,
    pub context: Context,
    pub state: TaskState,
    pub entry: fn(),
}

impl Task {
    pub fn new(id: usize, name: &'static str, entry: fn()) -> Self {
        Self {
            id,
            name,
            context: Context::default(),
            state: TaskState::Ready,
            entry,
        }
    }

    pub fn run(&self) {
        (self.entry)();
    }
}

use std::collections::VecDeque;
use crate::task::{Task, TaskState};

pub struct Scheduler {
    ready: VecDeque<Task>,
}

impl Scheduler {
    pub fn new() -> Self {
        Self { ready: VecDeque::new() }
    }

    pub fn add_task(&mut self, task: Task) {
        self.ready.push_back(task);
    }

    pub fn schedule(&mut self) {
        if let Some(mut task) = self.ready.pop_front() {
            println!("==============================");
            println!("Switch -> {} ({})", task.name, task.id);

            task.state = TaskState::Running;
            task.run();
            task.state = TaskState::Ready;

            self.ready.push_back(task);
        }
    }

    pub fn run(&mut self, rounds: usize) {
        for _ in 0..rounds {
            self.schedule();
        }
    }
}

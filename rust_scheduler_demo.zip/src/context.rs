#[derive(Debug, Clone, Default)]
pub struct Context {
    pub sp: usize,
    pub pc: usize,
    pub s0: usize,
    pub s1: usize,
    pub s2: usize,
    pub s3: usize,
}

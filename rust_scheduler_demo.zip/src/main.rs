use rust_scheduler_demo::scheduler::Scheduler;
use rust_scheduler_demo::task::Task;

fn init() {
    println!("init task");
}

fn shell() {
    println!("shell task");
}

fn network() {
    println!("network task");
}

fn main() {
    let mut scheduler = Scheduler::new();

    scheduler.add_task(Task::new(1, "init", init));
    scheduler.add_task(Task::new(2, "shell", shell));
    scheduler.add_task(Task::new(3, "network", network));

    scheduler.run(12);
}

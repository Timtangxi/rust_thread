# Rust Scheduler Demo

运行：

```bash
cargo run
```

这是一个最小 Round-Robin 调度器。

下一步建议：
1. 改为 #![no_std]
2. Task 保存内核栈
3. Context 增加全部寄存器
4. 编写 switch.S
5. 加入 Timer Interrupt
6. 在 QEMU(RISC-V) 中运行
